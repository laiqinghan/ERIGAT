#!/usr/bin/env python
# -*- coding:utf-8 -*-
"""
Created on 19/01/12 08:18:27

@author: Changzhi Sun
"""
import math

import torch
import torch.nn as nn
import torch.nn.functional as F

class GraphConvoluation(nn.Module):

    def __init__(self,
                 input_dim: int,
                 output_dim: int,
                 bias: bool = True) -> None:
        super(GraphConvoluation, self).__init__()
        self.input_dim = input_dim
        self.output_dim = output_dim
        self.weight = nn.Parameter(torch.FloatTensor(input_dim, output_dim))

        if bias:
            self.bias = nn.Parameter(torch.FloatTensor(output_dim))
        else:
            self.register_parameter('bias', None)
        self.reset_parameters()

    def reset_parameters(self) -> None:
        stdv = 1. / math.sqrt(self.weight.size(1))
        self.weight.data.uniform_(-stdv, stdv)
        if self.bias is not None:
            self.bias.data.uniform_(-stdv, stdv)


    def forward(self,
                inputs: torch.FloatTensor,
                adj: torch.sparse.FloatTensor) -> torch.FloatTensor:
        support = torch.mm(inputs, self.weight)
        #改
        attentionWeight=nn.Parameter(torch.ones(support.shape[0],support.shape[0]),requires_grad=True)
        attentionWeight = F.softmax(attentionWeight,dim=1)
        adj = adj.to_dense()*attentionWeight.cuda()
        #adj = adj.to_sparse()
        #change
        #  print(support)
        output = torch.mm(adj, support)
        #  print(output)
        #  print("======")
        if self.bias is not None:
            return output + self.bias
        return output


    def get_input_dim(self) -> int:
        return self.input_dim

    def get_output_dim(self) -> int:
        return self.output_dim


    def __repr__(self):
        return (self.__class__.__name__ + ' ('
                + str(self.input_dim) + ' -> '
                + str(self.output_dim) + ')')


class GCN(nn.Module):

    def __init__(self,
                 input_dim: int,
                 hidden_dim: int,
                 num_layers: int,
                 beta: float = 0.8,
                 dropout: float = 0.5) -> None:
        super(GCN, self).__init__()

        self.input_dim = input_dim
        self.hidden_dim = hidden_dim
        self.num_layers = num_layers
        self.beta = beta

        self.gc = nn.ModuleList([GraphConvoluation(input_dim if i == 0 else hidden_dim,
                                               hidden_dim) 
                             for i in range(num_layers)])
        self.dropout = nn.Dropout(dropout)

    def forward(self,
                inputs: torch.FloatTensor,
                adj: torch.sparse.FloatTensor) -> torch.FloatTensor:

        for i in range(self.num_layers):
            inputs = inputs * self.beta + (1 - self.beta) * F.relu(self.gc[i](inputs, adj))
            #  inputs = F.relu(self.gc[i](inputs, adj))
            inputs = self.dropout(inputs)
        return inputs


    def get_input_dim(self) -> int:
        return self.input_dim

    def get_output_dim(self) -> int:
        return self.hidden_dim

#  g = GCN(10, 10, 1)
#  inputs = torch.randn(2, 10)
#  i = torch.LongTensor([[0, 1],
                      #  [1, 0]])
#  v = torch.FloatTensor([1, 1])
#  adj = torch.sparse.FloatTensor(i, v, torch.Size([2, 2]))
#  print(adj)
#  print(torch.spmm(adj, inputs))
#  print(adj.to_dense())
#  print(torch.spmm(adj.to_dense(), inputs))
#  print(inputs)
#  print(g(inputs, adj))

class IGAT(nn.Module):

    def __init__(self, input_dim, hidden_dim, num_layers, beta, dropout):
        """Dense version of GAT."""
        super(IGAT, self).__init__()
        self.dropout = dropout

        #config
        self.alpha = 0.2
        #conll 2  ADE 3
        self.nheads = 1
        #conll 1  ADE 2
        self.num_layers = num_layers
        #conll 16 ADE 16
        self.attention_hidden = 32
        self.beta = beta
        #hidden_dim = hidden_dim / self.nheads
        hidden_dim = 128
        attentions = nn.ModuleList([ImprovedGraphAttentionLayer(input_dim, hidden_dim, attention_hidden=self.attention_hidden,dropout=dropout, alpha=self.alpha, concat=True)
                           for _ in range(self.nheads)])
        # for i, attention in enumerate(self.attentions):
        #     self.add_module('attention_{}'.format(i), attention)

        self.gc = nn.ModuleList([attentions for _ in range(self.num_layers)])

    def forward(self, inputs, adj):
        # x = F.dropout(x, self.dropout, training=self.training)
        # x = torch.cat([att(x, adj) for att in self.attentions], dim=1)
        # x = F.dropout(x, self.dropout, training=self.training)
        adj = adj.to_dense()

        #my
        pad_one = torch.ones_like(adj)
        pad_zero = torch.zeros_like(adj)
        orign_adj = torch.where(adj>0,pad_one,pad_zero)



        for i in range(self.num_layers):
            inputs2 = torch.cat([att(inputs, adj,orign_adj) for att in self.gc[i]], dim=1)
            inputs = inputs2
            # inputs = inputs * self.beta + (1 - self.beta) * inputs2
            # inputs = inputs * self.beta + (1 - self.beta) * F.relu(self.gc[i](inputs, adj))
            #  inputs = F.relu(self.gc[i](inputs, adj))
            # inputs = self.dropout(inputs)
        return inputs

    def get_input_dim(self) -> int:
        return self.input_dim

    def get_output_dim(self) -> int:
        return self.hidden_dim


class ImprovedGraphAttentionLayer(nn.Module):
    """
    Simple GAT layer, similar to https://arxiv.org/abs/1710.10903
    """

    def __init__(self, in_features, out_features, attention_hidden, dropout, alpha, concat=True):
        super(ImprovedGraphAttentionLayer, self).__init__()
        self.dropout = dropout
        self.in_features = in_features
        self.out_features = out_features
        self.alpha = alpha
        self.concat = concat
        self.attention_hidden = attention_hidden

        self.W = nn.Parameter(torch.zeros(size=(in_features, out_features)))
        nn.init.xavier_uniform_(self.W.data, gain=1.414)
        self.a = nn.Parameter(torch.zeros(size=(2*out_features, 1)))
        nn.init.xavier_uniform_(self.a.data, gain=1.414)

        #采用何凯明提出方法初始化矩阵
        self.W_s = nn.Parameter(torch.zeros(size=(in_features, attention_hidden)))
        nn.init.kaiming_normal_(self.W_s)

        self.W_t = nn.Parameter(torch.zeros(size=(attention_hidden, out_features)))
        nn.init.kaiming_normal_(self.W_t)

        self.leakyrelu = nn.LeakyReLU(self.alpha)

    def forward(self, input, adj, orign_adj):
        h = torch.mm(input, self.W_s)
        N = h.size()[0]

        flatten_orign_adj = orign_adj.view(N*N,-1)
        batch_attention = h.repeat(1, N).view(N * N, -1)*flatten_orign_adj
        batch_attention_relu = F.leaky_relu(batch_attention,self.alpha)
        batch_attention_relu_norm = batch_attention_relu.norm(2,dim=1).view(N,-1)
        zero_vec = -9e15 * torch.ones_like(batch_attention_relu_norm)
        my_attention = torch.where(orign_adj > 0, batch_attention_relu_norm, zero_vec)
        my_attention_reg = F.softmax(my_attention,dim=1)

        adj_norm = self.normalize_adj(orign_adj,my_attention_reg,True)
        adj_norm=adj_norm.cuda()
        conv_output = torch.mm(torch.mm(adj_norm,h), self.W_t)
        conv_output_relu = F.relu(conv_output)
        return conv_output_relu

        #
        # a_input = torch.cat([h.repeat(1, N).view(N * N, -1), h.repeat(N, 1)], dim=1).view(N, -1, 2 * self.out_features)
        # e = self.leakyrelu(torch.matmul(a_input, self.a).squeeze(2))
        #
        # zero_vec = -9e15*torch.ones_like(e)
        #
        # attention = torch.where(adj > 0, e, zero_vec)
        # attention = F.softmax(attention, dim=1)
        # attention = F.dropout(attention, self.dropout, training=self.training)
        # h_prime = torch.matmul(attention, h)
        #
        # if self.concat:
        #     return F.elu(h_prime)
        # else:
        #     return h_prime



    def __repr__(self):
        return self.__class__.__name__ + ' (' + str(self.in_features) + ' -> ' + str(self.attention_hidden)+ ' -> '+ str(self.out_features) + ')'

    def normalize_adj(self, A, attention, symmetric=True):
        # A = A+I
        A=A.cpu()
        attention = attention.cpu()
        A = A + torch.eye(A.size(0))
        # 所有节点的度
        d = A.sum(1)
        if symmetric:
            # D = D^-1/2
            D = torch.diag(torch.pow(d, -0.5))
            return D.mm(attention).mm(D)
        else:
            # D=D^-1
            D = torch.diag(torch.pow(d, -1))
            return D.mm(A)










class GraphAttentionLayer(nn.Module):
    """
    Simple GAT layer, similar to https://arxiv.org/abs/1710.10903
    """

    def __init__(self, in_features, out_features, dropout, alpha, concat=True):
        super(GraphAttentionLayer, self).__init__()
        self.dropout = dropout
        self.in_features = in_features
        self.out_features = out_features
        self.alpha = alpha
        self.concat = concat

        self.W = nn.Parameter(torch.zeros(size=(in_features, out_features)))
        nn.init.xavier_uniform_(self.W.data, gain=1.414)
        self.a = nn.Parameter(torch.zeros(size=(2*out_features, 1)))
        nn.init.xavier_uniform_(self.a.data, gain=1.414)

        self.leakyrelu = nn.LeakyReLU(self.alpha)

    def forward(self, input, adj):
        h = torch.mm(input, self.W)
        N = h.size()[0]

        a_input = torch.cat([h.repeat(1, N).view(N * N, -1), h.repeat(N, 1)], dim=1).view(N, -1, 2 * self.out_features)
        e = self.leakyrelu(torch.matmul(a_input, self.a).squeeze(2))

        zero_vec = -9e15*torch.ones_like(e)
        attention = torch.where(adj > 0, e, zero_vec)
        attention = F.softmax(attention, dim=1)
        attention = F.dropout(attention, self.dropout, training=self.training)
        h_prime = torch.matmul(attention, h)

        if self.concat:
            return F.elu(h_prime)
        else:
            return h_prime

    def __repr__(self):
        return self.__class__.__name__ + ' (' + str(self.in_features) + ' -> ' + str(self.out_features) + ')'



class GAT(nn.Module):
    def __init__(self, input_dim, hidden_dim, num_layers, beta, dropout):
        """Dense version of GAT."""
        super(GAT, self).__init__()
        self.dropout = dropout

        self.alpha = 0.2
        self.nheads = 2
        self.num_layers = num_layers
        self.beta = beta

        self.attentions = [GraphAttentionLayer(input_dim, hidden_dim, dropout=dropout, alpha=self.alpha, concat=True) for _ in range(self.nheads)]
        for i, attention in enumerate(self.attentions):
            self.add_module('attention_{}'.format(i), attention)

        self.gc = nn.ModuleList([self.attentions for _ in range(self.num_layers)])

    def forward(self, x, adj):
        # x = F.dropout(x, self.dropout, training=self.training)
        # x = torch.cat([att(x, adj) for att in self.attentions], dim=1)
        # x = F.dropout(x, self.dropout, training=self.training)

        for i in range(self.num_layers):
            inputs = inputs * self.beta + (1 - self.beta) * F.relu(self.gc[i](inputs, adj))
            #  inputs = F.relu(self.gc[i](inputs, adj))
            inputs = self.dropout(inputs)
        return inputs